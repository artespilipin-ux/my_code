Сервер персонального ассистента подготовлен. Рабочая папка: /srv/hermes/workspace. Сервис gateway: hermes-gateway.service. Telegram-доступ ограничен TELEGRAM_ALLOWED_USERS.
